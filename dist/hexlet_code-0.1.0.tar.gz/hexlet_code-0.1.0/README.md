[![Maintainability](https://api.codeclimate.com/v1/badges/311e130f0af3955c9cc2/maintainability)](https://codeclimate.com/github/Vladimir-SVI/project_one/maintainability)

EVEN
[![asciicast](https://asciinema.org/a/kQWZ7ZolBlLzCP4xALDa58sB5.svg)](https://asciinema.org/a/kQWZ7ZolBlLzCP4xALDa58sB5)

CALC
[![asciicast](https://asciinema.org/a/17OGk9Nrnr6EIhqELOy5xF8l6.svg)](https://asciinema.org/a/17OGk9Nrnr6EIhqELOy5xF8l6)

GCD
[![asciicast](https://asciinema.org/a/AoZ56964CrKcLmdszKu2zItwn.svg)](https://asciinema.org/a/AoZ56964CrKcLmdszKu2zItwn)

PROGRESSION
[![asciicast](https://asciinema.org/a/tTLmhmfp71jG3XZcF5BSVAR5S.svg)](https://asciinema.org/a/tTLmhmfp71jG3XZcF5BSVAR5S)